# Tushar Alase — Engineering Portfolio

Astro portfolio for embedded firmware, industrial IoT, robotics, and edge computing.

## GitHub Pages deployment

Use a public repository named `<GitHub-username>.github.io` for deployment at the account root. In Settings → Pages, select GitHub Actions as the source. Push these files to the main branch; the included workflow builds and deploys the portfolio.

The root-domain repository is required by this configuration: internal links currently begin with `/`. A project repository would require base-path support before deployment.

## Local development

Requires Node.js 22 and npm.

```sh
npm ci
npm run dev
```

Run `npm run build` to produce the static site in `dist/`.

## Editing

Project descriptions and page sections: `src/pages/index.astro`.
Styles: `src/assets/styles/portfolio.css`.
Metadata and font imports: `src/layouts/Base.astro`.
Résumé: `public/Tushar_Alase_Resume.pdf`.

Adapted from Astrofolio; see TEMPLATE-NOTICE.md. No ChatGPT hosting credentials or Site identifiers are included.
